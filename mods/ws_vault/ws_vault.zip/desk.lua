local modname = minetest.get_current_modname() or "ws_vault"


minetest.register_node(modname..":vault_desk", {
    description = "Vault Desk",
    drawtype = "mesh",
    mesh = "WLS_desk.gltf",      
    tiles = {
        "ws_core:planks_old.png",           
        "ws_core:log_oak_dry.png"         
    },
    paramtype = "light",
    walkable = true,
    diggable = true,
    groups = {choppy=3, oddly_breakable_by_hand=3},

    collision_box = {
        type = "fixed",
        fixed = {-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}, 
    },
    selection_box = {
        type = "fixed",
        fixed = {-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
    },
})
